package be.odisee.gebruikers;

import java.util.List;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.*;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Stap2StepDefinitions {
	
	WebDriver driver = new FirefoxDriver();
	LoginPage loginpage;
	HomePage homepage;
	ListUsersPage listuserpage;
	UserDetailsPage userdetailpage;
	
	@Given("^ik ben aangemeld als een administrator$")
	public void ik_ben_aangemeld_als_een_administrator() throws Throwable {
		loginpage = new LoginPage(driver);
		loginpage.open();
		homepage = loginpage.login("admin@mail.be", "abc123");
		Assert.assertTrue("Niet kunnen aanmelden.", homepage.getPageText().contains("Welkom"));
	}
	
	@Given("^ik ben op de pagina met de lijst van gebruikers$")
	public void ik_ben_op_de_pagina_met_de_lijst_van_gebruikers() throws Throwable {
		listuserpage = (ListUsersPage)homepage.chooseRole("Administrator");
		Assert.assertTrue("Niet op de lijst van gebruikers geraakt.", listuserpage.getTitle().contains("Lijst van de personen"));
	}

	@Given("^ik navigeer naar de gebruiker met de gebruikersnaam \"([^\"]*)\"$")
	public void ik_navigeer_naar_de_gebruiker_met_de_gebruikersnaam(String gebruikersnaam) throws Throwable {
		userdetailpage = listuserpage.chooseUser(gebruikersnaam);
		Assert.assertTrue("Niet op de detailpagina van de gebruiker geraakt.", userdetailpage.getTitle().contains("Details van Gebruiker"));
	}

	@Given("^ik verwijder de gebruiker$")
	public void ik_verwijder_de_gebruiker() throws Throwable {
		listuserpage = userdetailpage.chooseDeleteUser();
	}

	@Then("^kom ik naar de lijst van de gebruikers$")
	public void kom_ik_naar_de_lijst_van_de_gebruikers() throws Throwable {
		Assert.assertTrue("Niet op de lijst met gebruikers terechtgekomen", listuserpage.getTitle().equals("Lijst van de personen"));
	}

	@Then("^is gebruiker \"([^\"]*)\" niet meer in de lijst$")
	public void is_gebruiker_niet_meer_in_de_lijst(String gebruikersnaam) throws Throwable {
		String lijst = listuserpage.getList();
		Assert.assertFalse("Gebruiker bestaat nog terwijl hij werd verwijdert.", lijst.contains(gebruikersnaam));
	}
	
	@Then("^sluit ik de browser$")
	public void sluit_ik_de_browser() throws Throwable {
		listuserpage.CloseBrowser();
	}
}
