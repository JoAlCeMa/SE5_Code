package be.odisee.gebruikers;

import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.*;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Stap1StepDefinitions {
	
	WebDriver driver = new FirefoxDriver();
	
	@Given("^ik ben aangemeld als een administrator$")
	public void ik_ben_aangemeld_als_een_administrator() throws Throwable {
		driver.navigate().to("http://localhost:8080/brainstorm2015WA3/login");
		driver.findElement(By.id("username")).sendKeys("admin@mail.be");
		driver.findElement(By.id("password")).sendKeys("abc123");
		driver.findElement(By.id("submit")).click();
		Assert.assertTrue("Niet kunnen aanmelden.", driver.findElement(By.tagName("body")).getText().contains("Welkom"));
	}
	
	@Given("^ik ben op de pagina met de lijst van gebruikers$")
	public void ik_ben_op_de_pagina_met_de_lijst_van_gebruikers() throws Throwable {
		driver.findElement(By.linkText("Administrator")).click();
		Assert.assertTrue("Niet op de lijst van gebruikers geraakt.", driver.findElement(By.tagName("h1")).getText().contains("Lijst van de personen"));
	}

	@Given("^ik navigeer naar de gebruiker met de gebruikersnaam \"([^\"]*)\"$")
	public void ik_navigeer_naar_de_gebruiker_met_de_gebruikersnaam(String gebruikersnaam) throws Throwable {
		driver.findElement(By.linkText(gebruikersnaam)).click();
		Assert.assertTrue("Niet op de detailpagina van de gebruiker geraakt.", driver.findElement(By.tagName("h1")).getText().contains("Details van Gebruiker"));
	}

	@Given("^ik verwijder de gebruiker$")
	public void ik_verwijder_de_gebruiker() throws Throwable {
		driver.findElement(By.linkText("Verwijder persoon")).click();
	}

	@Then("^kom ik naar de lijst van de gebruikers$")
	public void kom_ik_naar_de_lijst_van_de_gebruikers() throws Throwable {
		String titel = driver.findElement(By.tagName("h1")).getText();
		Assert.assertTrue("Niet op de lijst met gebruikers terechtgekomen", titel.equals("Lijst van de personen"));
	}

	@Then("^is gebruiker \"([^\"]*)\" niet meer in de lijst$")
	public void is_gebruiker_niet_meer_in_de_lijst(String gebruikersnaam) throws Throwable {
		String lijst = driver.findElement(By.tagName("ul")).getText();
		Assert.assertFalse("Gebruiker bestaat nog terwijl hij werd verwijdert.", lijst.contains(gebruikersnaam));
	}
	
	@Then("^sluit ik de browser$")
	public void sluit_ik_de_browser() throws Throwable {
		driver.quit();
	}
}
