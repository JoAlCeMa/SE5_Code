package be.odisee.gebruikers;

import org.openqa.selenium.*;

public class UserDetailsPage extends AbstractPage {

	public UserDetailsPage(WebDriver driver) {
		super(driver);
	}
	
	public ListUsersPage chooseDeleteUser() {
		driver.findElement(By.linkText("Verwijder persoon")).click();
		return new ListUsersPage(driver);
	}
	
	public String getTitle() {
		return driver.findElement(By.tagName("h1")).getText();
	}
}
